#include <gpiod.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include "piolib.h"
#include "ws2812.pio.h"

#define NUM_TRAINS 5       // Number of trains
#define TRAIN_LENGTH 10    // Length of each train in LEDs
#define PIXELS 144         // Total number of LEDs in the strip
#define GPIO_CHIP "gpiochip0"  // GPIO chip name
#define NUM_IR_SENSORS (sizeof(ir_pins) / sizeof(ir_pins[0]))


uint8_t ir_pins[] = {17, 26, 27, 24};  

// Define a brightness variable (0 to 255)
uint8_t brightness = 10;  // Half brightness (can be adjusted)

void set_brightness(uint8_t value) {
    brightness = value;
}

// Function to scale color values based on brightness
uint8_t scale_brightness(uint8_t color, uint8_t brightness) {
    return (color * brightness) / 255;
}

// Function to initialize the train positions
void initialize_train_positions(uint8_t train_positions[], uint8_t num_trains, uint8_t pixels) {
    for (uint8_t i = 0; i < num_trains; i++) {
        train_positions[i] = (i * pixels) / num_trains;  // Space trains evenly
    }
}

// Function to update the LED strip with multiple trains and a white background
void update_led_strip(uint8_t databuf[], uint8_t train_positions[], uint8_t num_trains, uint8_t train_length, uint8_t pixels) {
    // Set the background color to white for all LEDs, with adjustable brightness
    for (uint8_t i = 0; i < pixels; i++) {
        databuf[4 * i + 0] = scale_brightness(0xFF, brightness);  // White (W)
        databuf[4 * i + 1] = scale_brightness(0xFF, brightness);  // Blue (B)
        databuf[4 * i + 2] = scale_brightness(0xFF, brightness);  // Red (R)
        databuf[4 * i + 3] = scale_brightness(0xFF, brightness);  // Green (G)
    }

    // Draw each train on top of the background, with adjustable brightness
    for (uint8_t t = 0; t < num_trains; t++) {
        for (uint8_t l = 0; l < train_length; l++) {
            int led_pos = (train_positions[t] + l) % pixels;  // Wrap around if needed

            // Set the color for the train (0x087200 in RGBW format), with adjustable brightness
            databuf[4 * led_pos + 0] = scale_brightness(0x00, brightness);  // White (W)
            databuf[4 * led_pos + 1] = scale_brightness(0x00, brightness);  // Blue (B)
            databuf[4 * led_pos + 2] = scale_brightness(0x08, brightness);  // Red (R)
            databuf[4 * led_pos + 3] = scale_brightness(0x65, brightness);  // Green (G)
        }
    }
}

int main(int argc, const char **argv) {
    struct gpiod_chip *chip = gpiod_chip_open_by_name(GPIO_CHIP);
    if (!chip) {
        perror("Failed to open GPIO chip");
        return 1;
    }

    struct gpiod_line *lines[NUM_IR_SENSORS];

    // Initialize each IR sensor GPIO pin
    for (size_t i = 0; i < NUM_IR_SENSORS; i++) {
        lines[i] = gpiod_chip_get_line(chip, ir_pins[i]);
        if (!lines[i]) {
            perror("Failed to get GPIO line");
            gpiod_chip_close(chip);
            return 1;
        }

        if (gpiod_line_request_input(lines[i], "ir_sensor") < 0) {
            perror("Failed to request GPIO line as input");
            gpiod_chip_close(chip);
            return 1;
        }
    }

    // Read and print sensor states in a loop
    printf("Reading GPIO pins {17, 26, 27, 24}. Press Ctrl+C to exit.\n");
    PIO pio;
    uint8_t sm1, sm2;
    uint offset;
    uint gpio1 = 3;  // LED strip on pin 3
    uint gpio2 = 2;  // LED strip on pin 2
    uint8_t databuf1[PIXELS * 4];
    uint8_t databuf2[PIXELS * 4];
    uint8_t train_positions[NUM_TRAINS];

    if (argc == 2)
        gpio1 = (uint)strtoul(argv[1], NULL, 0);

    // Initialize PIO and SMs
    pio = pio0;
    sm1 = pio_claim_unused_sm(pio, true);
    sm2 = pio_claim_unused_sm(pio, true);
    pio_sm_config_xfer(pio, sm1, PIO_DIR_TO_SM, 256, 1);
    pio_sm_config_xfer(pio, sm2, PIO_DIR_TO_SM, 256, 1);

    offset = pio_add_program(pio, &ws2812_program);
    printf("Loaded program at %d, using sm %d and sm %d, gpio %d and gpio %d\n", offset, sm1, sm2, gpio1, gpio2);

    pio_sm_clear_fifos(pio, sm1);
    pio_sm_clear_fifos(pio, sm2);
    pio_sm_set_clkdiv(pio, sm1, 1.0);
    pio_sm_set_clkdiv(pio, sm2, 1.0);
    ws2812_program_init(pio, sm1, offset, gpio1, 800000.0, false);
    ws2812_program_init(pio, sm2, offset, gpio2, 800000.0, false);

    // Initialize train positions
    initialize_train_positions(train_positions, NUM_TRAINS, PIXELS);

    while (1) {
        // Update the LED strips with the current train positions and white background
        update_led_strip(databuf1, train_positions, NUM_TRAINS, TRAIN_LENGTH, PIXELS);
        update_led_strip(databuf2, train_positions, NUM_TRAINS, TRAIN_LENGTH, PIXELS);

        // Send the updated LED data to the strips
        pio_sm_xfer_data(pio, sm1, PIO_DIR_TO_SM, sizeof(databuf1), databuf1);
        pio_sm_xfer_data(pio, sm2, PIO_DIR_TO_SM, sizeof(databuf2), databuf2);

        // Move the trains forward
        for (uint8_t t = 0; t < NUM_TRAINS; t++) {
            train_positions[t] = (train_positions[t] + 1) % PIXELS;  // Wrap around if needed
        }


            for (size_t i = 0; i < NUM_IR_SENSORS; i++) {
            int state = gpiod_line_get_value(lines[i]);
            if (state < 0) {
                perror("Failed to read GPIO line");
            } else {
                printf("GPIO pin %d state: %d\n", ir_pins[i], state);
            }
        }

        // Delay to control the animation speed
        sleep_ms(50);  // Adjust this value to change the speed
    }
        // Cleanup
    for (size_t i = 0; i < NUM_IR_SENSORS; i++) {
        gpiod_line_release(lines[i]);
    }
    gpiod_chip_close(chip);
    return 0;
}
